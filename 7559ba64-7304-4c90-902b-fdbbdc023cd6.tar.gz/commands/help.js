
const { MessageEmbed, MessageActionRow, MessageSelectMenu, MessageButton } = require("discord.js");
const config = require('../config.json');
const { prefix } = require('../config.json')

module.exports.run = async (client, message, args) => {

const help = new MessageEmbed()
.setTitle(`${client.user.username}'s Help Panel`)
.setColor('WHITE')
.setDescription(`**Hey ${message.author}, I'm ${message.client.user} a giveaway bot with awesome features!**`)
.addField(`<:zen_stack:964471759023771658> Categories`, "> <a:Tada_Animated:911306242360750171> `::` **Giveaway**\n> <a:timer:906790907788025896> `::` **General**", true)
.addField(`<a:stats:906790955582124112> Stats:`, `> <a:music:906791418708779058> **Ping \`:\` ${Date.now() - message.createdTimestamp}ms**\n> **<a:yes:906785808940425267> Servers \`:\` ${client.guilds.cache.size} Guilds**\n> **<a:developer_badge:906786359925170176> Made by: [Nightmary#9992](https://dsc.gg/clevemsc)**`, true)
.setThumbnail(message.client.user.displayAvatarURL({ dynamic: true }))
.setTimestamp()
.setFooter(`Requested by ${message.author.username}`, message.author.displayAvatarURL());

const home = new MessageEmbed()
.setTitle(`${client.user.username}'s Help Panel`)
.setColor('WHITE')
.setDescription(`**Hey ${message.author}, I'm ${message.client.user} a giveaway bot with awesome features!**`)
.addField(`<:zen_stack:964471759023771658> Categories`, "> 🎁 `::` **Giveaway**\n> <:zen_general:965441035536830515> `::` **General**", true)
.addField(`<:zen_servers:964873981758939137> Stats:`, `> <:zen_stats:964873844978491452> **Ping \`:\` ${Date.now() - message.createdTimestamp}ms**\n> **<:zen_members:962241723910746172> Servers \`:\` ${client.guilds.cache.size} Guilds**\n> **<:zen_logo2:964468647986876426> Made by: [Nightmary#9992](https://dsc.gg/clevemsc)**`, true)
.setThumbnail(message.client.user.displayAvatarURL({ dynamic: true }))
.setTimestamp()
.setFooter(`Requested by ${message.author.username}`, message.author.displayAvatarURL());

  const giveaway = new MessageEmbed()
  .setTitle("Categories » Giveaway")
  .setColor('WHITE')
  .setDescription("```Giveaway Manager's Giveaway Commands```")
  .addFields(
    { name: 'Create / Start'  , value: `Start a giveaway in your guild!\n**\`${prefix}start/create\`**`, inline: true },
    { name: 'Edit' , value: `Edit an already running giveaway!\n**\`${prefix}edit\`**`, inline: true },
    { name: 'End' , value: `End an already running giveaway!\n**\`${prefix}end\`**`, inline: true },
    { name: 'List' , value: `List all the giveaways running within this guild!\n**\`${prefix}list\`**`, inline: true },
    { name: 'Pause' , value: `Pause an already running giveaway!\n**\`${prefix}pause\`**`, inline: true },
    { name: 'Reroll' , value: `Reroll an ended giveaway!\n **\`${prefix}reroll\`**`, inline: true },
    { name: 'Resume' , value: `Resume a paused giveaway!\n **\`${prefix}resume\`**`, inline: true },
  )
  .setTimestamp()
  .setFooter(`Requested by ${message.author.username}`, message.author.displayAvatarURL());


  const general = new MessageEmbed()
  .setTitle("Categories » General")
  .setColor('WHITE')
  .setDescription("```Giveaway Manager's General Help```")
  .addFields(
    { name: 'Help'  , value: `Shows all commands to this bot!\n\`${prefix}help\``, inline: true },
    { name: 'Invite' , value: `Get the bot's invite link!\n\`${prefix}invite\``, inline: true },
    { name: 'Info' , value: `Check the bot's uptime!\n\`${prefix}info\``, inline: true },
  )
  .setTimestamp()
  .setFooter(`Requested by ${message.author.username}`, message.author.displayAvatarURL());

  const components = (state) => [
    new MessageActionRow().addComponents(
        new MessageSelectMenu()
        .setCustomId("help-menu")
        .setPlaceholder("Please Select a Category")
        .setDisabled(state)
        .addOptions([
            {
                label: `Home`,
                value: `home`,
                description: `View my Overview`,
                emoji: `🏠`
            },
            {
                label: `Giveaways`,
                value: `giveaway`,
                description: `View all the giveaway based commands!`,
                emoji: `965439275388784741`
            },
            {
                label: `General`,
                value: `general`,
                description: `View all the general bot commands!`,
                emoji: `965441035536830515`
            }
        ])
    ),
];

const initialMessage = await message.channel.send({ embeds: [help], components: components(false) });

const filter = (interaction) => interaction.user.id === message.author.id;

        const collector = message.channel.createMessageComponentCollector(
            {
                filter,
                componentType: "SELECT_MENU",
                time: 300000
            });

        collector.on('collect', (interaction) => {
            if (interaction.values[0] === "home") {
                interaction.update({ embeds: [home], components: components(false) });
            } else if (interaction.values[0] === "giveaway") {
                interaction.update({ embeds: [giveaway], components: components(false) });
            } else if (interaction.values[0] === "general") {
                interaction.update({ embeds: [general], components: components(false) });
            }
            
        });
        collector.on('end', () => {
          initialMessage.edit({ components: components(true) });
      }
      )
}

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/