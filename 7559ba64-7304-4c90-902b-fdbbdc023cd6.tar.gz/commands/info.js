const { MessageEmbed, Discord, MessageActionRow, MessageButton } = require('discord.js');
const config = require('../config.json');

module.exports.run = async (client, message, args) => {

            
    const days = Math.floor(client.uptime / 86400000)
    const hours = Math.floor(client.uptime / 3600000) % 24
    const minutes = Math.floor(client.uptime/ 60000) % 60 //1 Hour = 60 Minutes
    const seconds = Math.floor(client.uptime / 1000) % 60 //1 Minute = 60 Seconds

    const info = new MessageEmbed()
    .setTitle("Giveaway Manager's Informations")
    .addField("Changelog", 'Version: `1.0`\n[YouTube](https://youtube.com/c/Vers13)', true)
    .addField("Uptime", `**\`${days} Day(s)\` \`${hours} Hour(s)\` \`${minutes} Min(s)\` Uptime**`)
    .addField("Creator:", "Nightmary#9992", true)
    .setThumbnail(message.client.user.displayAvatarURL({ dynamic: true }))
    .setColor("WHITE")
    .setFooter(`Requested by: ${message.author.username} | Giveaway Manager`,message.author.displayAvatarURL({ dynamic: true }))
    .setTimestamp()

    const row = new MessageActionRow()
    .addComponents(
            new MessageButton()
            .setLabel('Upvote')
            .setURL("Soon!!")
            .setStyle('LINK'),

            new MessageButton()
            .setLabel('Invite Me')
            .setEmoji("961977218844729365")
            .setURL("https://discord.com/api/oauth2/authorize?client_id=965565644856786984&permissions=8&scope=bot%20applications.commands")
            .setStyle('LINK'),
            
            new MessageButton()
            .setLabel('Support')
            .setURL("dsc.gg/clevemsc")
            .setStyle('LINK'),
    )
  message.channel.send({ content: " ", embeds: [info], components: [row] })
}
