const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const config = require('../config.json');

module.exports.run = async (client, message, args) => {
    const row = new MessageActionRow()
    .addComponents(
        new MessageButton()
        .setLabel('Upvote')
        .setURL("https://discordbotlist.com/")
        .setStyle('LINK'),
        
        new MessageButton()
        .setLabel(`Invite Me`)
        .setStyle('LINK')
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`),
       
        new MessageButton()
        .setLabel('Support')
        .setStyle('LINK')
        .setURL("https://discord.gg/WvMbuGj6VZ"),
    )
    let invite = new MessageEmbed()
    .setAuthor(`Invite ${client.user.username} `, client.user.avatarURL())
    .setTitle("Invite & Support Link!")
    .setDescription(`Invite ${client.user} to your server, and experience the bot with the community!`)
    .setColor('WHITE')
    .setTimestamp()
    .setFooter(`Requested by ${message.author.tag}`, message.author.displayAvatarURL())
    message.channel.send({ embeds: [invite], components: [row]});
}

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/