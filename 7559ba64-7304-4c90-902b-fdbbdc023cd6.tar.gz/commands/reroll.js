const { MessageEmbed } = require('discord.js');
const ms = require('ms');
module.exports.run = async (client, message, args) => {

    // If the member doesn't have enough permissions
    if(!message.member.permissions.has('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")){
        const error1 = new MessageEmbed()
        .setTitle("<:zen_wrong:964458428024098896> ERROR")
        .serDescription(`${message.author}, You need to have the manage messages permissions to reroll giveaways.`)
        .setColor('RED')
        .setFooter(`Requested by ${message.author.tag}`, message.author.displayAvatarURL())
        return message.channel.send({ embeds: [error1] });
    }

    // If no message ID or giveaway name is specified
    if(!args[0]){
        const error = new MessageEmbed()
        .setTitle("<:zen_wrong:964458428024098896> ERROR")
        .serDescription(`${message.author}, You have to specify a valid message ID`)
        .setColor('RED')
        .setFooter(`Requested by ${message.author.tag}`, message.author.displayAvatarURL())
        return message.channel.send({ embeds: [error] });
    }

    // try to found the giveaway with prize then with ID
    let giveaway = 
    // Search with giveaway prize
    client.giveawaysManager.giveaways.find((g) => g.prize === args.join(' ')) ||
    // Search with giveaway ID
    client.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

    // If no giveaway was found
    if(!giveaway){
        const error3 = new MessageEmbed()
        .setTitle("<:zen_wrong:964458428024098896> ERROR")
        .serDescription('Unable to find a giveaway for `'+ args.join(' ') +'`.')
        .setColor('RED')
        .setFooter(`Requested by ${message.author.tag}`, message.author.displayAvatarURL())
        return message.channel.send({ embeds: [error3] });
    }

    // Reroll the giveaway
    client.giveawaysManager.reroll(giveaway.messageID)
    .then(() => {
        // Success message
        const success = new MessageEmbed()
        .setTitle("<:zen_check:956857227917033482> SUCCESS")
        .serDescription('Giveaway rerolled!')
        .setColor('GREEN')
        .setFooter(`Requested by ${message.author.tag}`, message.author.displayAvatarURL())
        message.channel.send({ embeds: [success]  });
    })
    .catch((e) => {
        if(e.startsWith(`Giveaway with message ID ${giveaway.messageID} is not ended.`)){
            message.reply('This giveaway is not ended!');
        } else {
            console.error(e);
            message.reply(e);
        }
    });

};

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/