const register = require('../../utils/slashsync');
module.exports = async (client) => {
  await register(client, client.register_arr.map((command) => ({
    name: command.name,
    description: command.description,
    options: command.options,
    type: 'CHAT_INPUT'
  })), {
    debug: true
  });
  // Register slash commands - ( If you are one of those people who read the codes I highly suggest ignoring this because I am very bad at what I am doing, thanks LMAO )
  console.log(`[ / | Slash Command ] - ✅ Loaded all slash commands!`)
  let invite = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`;
  console.log(`[STATUS] ${client.user.tag} is now online!\n[INFO] Bot by benzmeister#5843. https://www.youtube.com/channel/UCyIdkBKTICWpin3HHac10Pg\n[Invite Link] ${invite}`);
    const activities = [
  `🎉 dsc.gg/clevemsc`,
  `${client.guilds.cache.size} servers`,
  `${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} members`,
  `dsc.gg/clevemsc`
];

let i = 0;
setInterval(() => client.user.setActivity(`/start | ${activities[i++ % activities.length]}`, { type: 'PLAYING'}), 60000);
client.user.setPresence({ game: { name: '' }, status: 'idle' });
};

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/
