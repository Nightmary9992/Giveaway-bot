const Discord = require("discord.js")
const { MessageEmbed } = require("discord.js");


module.exports = {
  async execute(giveaway, member, reaction){
    const embed = new MessageEmbed()
    .setAuthor("GIVEAWAY", '')
    .setDescription(`**Giveaway Is Now Ended Thanks for Participating!**`)
    .setColor("WHITE")
    .setFooter(member.user.username, member.user.displayAvatarURL())
    .setTimestamp()

     reaction.users.remove(member.user);
  member.send({ embeds: [embed] }).catch(e => {})
  }
}

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/