const Discord = require("discord.js")


module.exports = {
  async execute(giveaway, winners) {
    winners.forEach((member) => {
      member.send({
        embeds: [new Discord.MessageEmbed()
          .setAuthor(`🎉 CONGRATULATIONS`, '')
          .setColor("WHITE")
          .setThumbnail("")
          .setDescription(`> \`🏆\` · Congratulations ${member.user}\n> \`🎊\` · You Won **${giveaway.prize}!** \n> \`🎁\` · Giveaway [Click Here](https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${giveaway.messageId})\n> \`🎫\` · Make A Ticket To Claim Your Price!`)
          .setTimestamp()
          .setFooter(member.user.username, member.user.displayAvatarURL())
        ]
      }).catch(e => {})
    });

  }
}

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/