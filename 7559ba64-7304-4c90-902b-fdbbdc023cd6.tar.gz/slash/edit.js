const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'edit',
    description: '🎉 Edit a giveaway',

    options: [
        {
            name: 'giveaway',
            description: 'The giveaway to end (message ID)',
            type: 'STRING',
            required: true
        },
        {
            name: 'duration',
            description: 'Setting time of mentioned giveaway. Eg. 1h sets the current giveaway to end after an hour!',
            type: 'STRING',
            required: true
        },
        {
            name: 'winners',
            description: 'How many winners the giveaway should have',
            type: 'INTEGER',
            required: true
        },
        {
            name: 'prize',
            description: 'What the prize of the giveaway should be',
            type: 'STRING',
            required: true
        }
    ],

    run: async (client, interaction) => {

        // If the member doesn't have enough permissions
        if (!interaction.member.permissions.has('MANAGE_MESSAGES') && !interaction.member.roles.cache.some((r) => r.name === "Giveaways")) {
            const error = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896> ERROR")
            .setDescription(`${message.author}, You need to have the manage messages permissions to start giveaways.`)
            .setColor("RED")
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setTimestamp()
            return interaction.reply({ embeds: [error], ephemeral:true });
        }
        const gid = interaction.options.getString('giveaway');
        const time = interaction.options.getString('duration');
        const winnersCount = interaction.options.getInteger('winners');
        const prize = interaction.options.getString('prize');
        
        await interaction.deferReply({
         ephemeral: true
        })
        // Edit the giveaway
        try {
        await client.giveawaysManager.edit(gid, {
            newWinnersCount: winnersCount,
            newPrize: prize,
            addTime: time
        })
        } catch(e) {
            const error = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896>  ERROR")
            .setDescription(`No giveaway found with the given message ID: \`${gid}\``)
            .setColor("RED")
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setTimestamp()
return interaction.editReply({ embeds: [error], ephemeral: true });
        }
        const success = new MessageEmbed()
        .setTitle("<:zen_check:956857227917033482> SUCCESS")
        .setDescription(`This giveaway has now been edited!`)
        .setColor("GREEN")
        .setFooter(client.user.username, client.user.displayAvatarURL())
        .setTimestamp()
        interaction.editReply({ embeds: [success], ephemeral: true });
    }

};

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/
