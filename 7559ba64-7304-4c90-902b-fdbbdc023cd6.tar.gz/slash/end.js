const { MessageEmbed } = require("discord.js");

module.exports = {
    name: "end",
    description: '🎉 End an already running giveaway',

    options: [
        {
            name: 'giveaway',
            description: 'The giveaway to end (message ID or giveaway prize)',
            type: 'STRING',
            required: true
        }
    ],

    run: async (client, interaction) => {

        // If the member doesn't have enough permissions
        if (!interaction.member.permissions.has('MANAGE_MESSAGES') && !interaction.member.roles.cache.some((r) => r.name === "Giveaways")) {
            const error = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896>  ERROR")
            .setDescription(`You need to have the manage messages permissions to end giveaways.`)
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setColor("RED")
            .setTimestamp()
            return interaction.reply({ embeds: [error], ephemeral: true });
        }

        const query = interaction.options.getString('giveaway');

        // fetching the giveaway with message Id or prize
        const giveaway =
            // Search with giveaway prize
            client.giveawaysManager.giveaways.find((g) => g.prize === query && g.guildId === interaction.guild.id) ||
            // Search with giveaway Id
            client.giveawaysManager.giveaways.find((g) => g.messageId === query && g.guildId === interaction.guild.id);

        // If no giveaway was found with the corresponding input
        if (!giveaway) {
            const error1 = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896>  ERROR")
            .setDescription('Unable to find a giveaway for `' + query + '`.')
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setColor("RED")
            .setTimestamp()
            return interaction.reply({ embeds: [error1], ephemeral: true });
        }

        if (giveaway.ended) {
            const error2 = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896>  ERROR")
            .setDescription('This giveaway has already ended!')
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setColor("RED")
            .setTimestamp()
            return interaction.reply({ embeds: [error2], ephemeral: true });
        }

        // Edit the giveaway
        client.giveawaysManager.end(giveaway.messageId)
            // Success message
            .then(() => {
                // Success message
                const success = new MessageEmbed()
                .setTitle("<:zen_check:956857227917033482> SUCCESS")
                .setDescription(`**[This Giveaway](https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${giveaway.messageId})** Has Now Ended!`)
                .setFooter(client.user.username, client.user.displayAvatarURL())
                .setColor("GREEN")
                .setTimestamp()
                interaction.reply({ embeds: [success], ephemeral: true })
            .catch((e) => {
                interaction.reply({
                    content: e,
                    ephemeral: true
                });
            });

        },
    )}
}