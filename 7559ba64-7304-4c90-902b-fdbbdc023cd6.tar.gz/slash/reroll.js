const { MessageEmbed } = require("discord.js");

module.exports = {
    name: "reroll",
    description: '🎉 Reroll a giveaway',

    options: [
        {
            name: 'giveaway',
            description: 'The giveaway to reroll (message ID or prize)',
            type: 'STRING',
            required: true
        }
    ],

    run: async (client, interaction) => {

        // If the member doesn't have enough permissions
        if (!interaction.member.permissions.has('MANAGE_MESSAGES') && !interaction.member.roles.cache.some((r) => r.name === "Giveaways")) {
            const error = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896> ERROR")
            .setDescription("You need to have the manage messages permission to reroll giveaways")
            .setColor("RED")
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setTimestamp()
            return interaction.reply({ embeds: [error], ephemeral: true });
        }

        const query = interaction.options.getString('giveaway');

        // try to find the giveaway with the provided prize OR with the ID
        const giveaway =
            // Search with giveaway prize
            client.giveawaysManager.giveaways.find((g) => g.prize === query && g.guildId === interaction.guild.id) ||
            // Search with giveaway ID
            client.giveawaysManager.giveaways.find((g) => g.messageId === query && g.guildId === interaction.guild.id);

        // If no giveaway was found
        if (!giveaway) {
            const error1 = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896> ERROR")
            .setDescription('Unable to find a giveaway for `' + query + '`.')
            .setColor("RED")
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setTimestamp()
            return interaction.reply({ embeds: [error1], ephemeral: true });
        }

        if (!giveaway.ended) {
            const error2 = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896> ERROR")
            .setDescription(`[This Giveaway](https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${giveaway.messageId}) has not been ended yet`)
            .setColor("RED")
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setTimestamp()
            return interaction.reply({ embeds: [error2], ephemeral: true });
        }

        // Reroll the giveaway
        client.giveawaysManager.reroll(giveaway.messageId)
            .then(() => {
                const success = new MessageEmbed()
                .setTitle("<:zen_check:956857227917033482> SUCCESS")
                .setDescription(`Rerolled **[this giveaway](https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${giveaway.messageId})!**`)
                .setColor("GREEN")
                .setFooter(client.user.username, client.user.displayAvatarURL())
                .setTimestamp()
                // Success message
                interaction.reply({ embeds: [success], ephemeral: true })
            .catch((e) => {
                interaction.reply({
                    content: e,
                    ephemeral: true
                });
            });
        }
    )},
}

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/