const { MessageEmbed } = require("discord.js");


module.exports = {
    name: "resume",
    description: '▶ Resume a paused giveaway',

    options: [
        {
            name: 'giveaway',
            description: 'The giveaway to resume (message ID or giveaway prize)',
            type: 'STRING',
            required: true
        }
    ],

    run: async (client, interaction) => {

        // If the member doesn't have enough permissions
        if (!interaction.member.permissions.has('MANAGE_MESSAGES') && !interaction.member.roles.cache.some((r) => r.name === "Giveaways")) {
            const error = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896> ERROR")
            .setDescription("You need to have the manage messages permissions to pause giveaways.")
            .setColor("RED")
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setTimestamp()
            return interaction.reply({ embeds: [error], ephemeral: true });
        }

        const query = interaction.options.getString('giveaway');

        // try to find the giveaway with prize alternatively with ID
        const giveaway =
            // Search with giveaway prize
            client.giveawaysManager.giveaways.find((g) => g.prize === query && g.guildId === interaction.guild.id) ||
            // Search with giveaway ID
            client.giveawaysManager.giveaways.find((g) => g.messageId === query && g.guildId === interaction.guild.id);

        // If no giveaway was found
        if (!giveaway) {
            const error1 = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896> ERROR")
            .setDescription('Unable to find a giveaway for `' + query + '`.')
            .setColor("RED")
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setTimestamp()
            return interaction.reply({ embeds: [error1], ephemeral: true });
        }

        if (!giveaway.pauseOptions.isPaused) {
            const error2 = new MessageEmbed()
            .setTitle("<:zen_wrong:964458428024098896> ERROR")
            .setDescription(`**[This giveaway](https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${giveaway.messageId})**  is not paused!`)
            .setColor("RED")
            .setFooter(client.user.username, client.user.displayAvatarURL())
            .setTimestamp()
            return interaction.reply({ embeds: [error2], ephemeral: true });
        }

        // Edit the giveaway
        client.giveawaysManager.unpause(giveaway.messageId)
            // Success message
            .then(() => {
                const success = new MessageEmbed()
                .setTitle("<:zen_check:956857227917033482> SUCCESS")
                .setDescription(`**[This giveaway](https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${giveaway.messageId})** has been successfully resumed!`)
                .setColor("GREEN")
                .setFooter(client.user.username, client.user.displayAvatarURL())
                .setTimestamp()
                // Success message
                interaction.reply({ embeds: [success], ephemeral: true })
            .catch((e) => {
                interaction.reply({
                    content: e,
                    ephemeral: true
                });
            });
        }
    )}
}

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/