const Discord = require("discord.js")
const messages = require("../utils/message");
const ms = require("ms")
const { MessageEmbed } = require("discord.js");

module.exports = {
  name: 'start',
  description: '🎉 Start a giveaway',

  options: [
    {
      name: 'duration',
      description: 'How long the giveaway should last for. Example values: 1m, 1h, 1d',
      type: 'STRING',
      required: true
    },
    {
      name: 'winners',
      description: 'How many winners the giveaway should have',
      type: 'INTEGER',
      required: true
    },
    {
      name: 'prize',
      description: 'What the prize of the giveaway should be',
      type: 'STRING',
      required: true
    },
    {
      name: 'channel',
      description: 'The channel to start the giveaway in',
      type: 'CHANNEL',
      required: true
    },
    {
      name: 'bonusrole',
      description: 'Role which would recieve bonus entries',
      type: 'ROLE',
      required: false
    },
    {
      name: 'bonusamount',
      description: 'The amount of bonus entries the role will recieve',
      type: 'INTEGER',
      required: false
    },
    {
      name: 'role',
      description: 'Role you want to add as giveaway joining requirement',
      type: 'ROLE',
      required: false
    },
  ],

  run: async (client, interaction) => {

    // If the member doesn't have enough permissions
    if (!interaction.member.permissions.has('MANAGE_MESSAGES') && !interaction.member.roles.cache.some((r) => r.name === "Giveaways")) {
      const error4 = new MessageEmbed()
      .setTitle("<:zen_wrong:964458428024098896> ERROR")
      .setDescription(`You need to have the manage messages permissions to start giveaways.`)
      .setColor("RED")
      .setFooter(client.user.username, client.user.displayAvatarURL())
      .setTimestamp()
      return interaction.reply({ embeds: [error4], ephemeral: true });
    }

    const giveawayChannel = interaction.options.getChannel('channel');
    const giveawayDuration = interaction.options.getString('duration');
    const giveawayWinnerCount = interaction.options.getInteger('winners');
    const giveawayPrize = interaction.options.getString('prize');

    if (!giveawayChannel.isText()) {
      const error = new MessageEmbed()
      .setTitle("<:zen_wrong:964458428024098896> ERROR")
      .setDescription(`Please select a text channel!`)
      .setColor("RED")
      .setFooter(client.user.username, client.user.displayAvatarURL())
      .setTimestamp()
      return interaction.reply({ embeds: [error], ephemeral: true });
    }
   if(isNaN(ms(giveawayDuration))) {
    const error1 = new MessageEmbed()
    .setTitle("<:zen_wrong:964458428024098896> ERROR")
    .setDescription(`Please select a valid duration!`)
    .setColor("RED")
    .setFooter(client.user.username, client.user.displayAvatarURL())
    .setTimestamp()
    return interaction.reply({ embeds: [error1], ephemeral: true });
  }
    if (giveawayWinnerCount < 1) {
      const error2 = new MessageEmbed()
      .setTitle("<:zen_wrong:964458428024098896> ERROR")
      .setDescription(`Please select a valid winner count! greater or equal to one.`)
      .setColor("RED")
      .setFooter(client.user.username, client.user.displayAvatarURL())
      .setTimestamp()
      return interaction.reply({ embeds: [error2], ephemeral: true })
    }

    const bonusRole = interaction.options.getRole('bonusrole')
    const bonusEntries = interaction.options.getInteger('bonusamount')
    let rolereq = interaction.options.getRole('role')
    let invite = interaction.options.getString('invite')

    if (bonusRole) {
      if (!bonusEntries) {
        const error3 = new MessageEmbed()
        .setTitle("<:zen_wrong:964458428024098896> ERROR")
        .setDescription(`You must specify how many bonus entries would ${bonusRole} recieve!`)
        .setColor("RED")
        .setFooter(client.user.username, client.user.displayAvatarURL())
        .setTimestamp()
        return interaction.reply({ embeds: [error3], ephemeral: true });
      }
    }


    await interaction.deferReply({ ephemeral: true })
    let reqinvite;
    if (invite) {
      let invitex = await client.fetchInvite(invite)
      let client_is_in_server = client.guilds.cache.get(
        invitex.guild.id
      )
      reqinvite = invitex
      if (!client_is_in_server) {
        return interaction.editReply({
          embeds: [{
            color: "WHITE",
            author: {
              name: client.user.username,
              icon_url: client.user.avatarURL
            },
            title: "Server Check!",
            url: "https://www.youtube.com/channel/UCyIdkBKTICWpin3HHac10Pg/featured",
            description:
              "Come to the baddest Development server 💣",
            timestamp: new Date(),
            footer: {
              icon_url: client.user.avatarURL,
              text: "Server Check"
            }
          }]
        })
      }
    }

    if (rolereq && !invite) {

      messages.inviteToParticipate = `**React with 🎉 to  participate!**\n>>> - Only members having ${rolereq} are allowed to participate in this giveaway!`
    }
    if (rolereq && invite) {
      messages.inviteToParticipate = `**React with 🎉 to participate!**\n>>> - Only members having ${rolereq} are allowed to participate in this giveaway!\n- Members are required to join [this server](${invite}) to participate in this giveaway!`
    }
    if (!rolereq && invite) {
      messages.inviteToParticipate = `**React with 🎉 to participate!**\n>>> - Members are required to join [this server](${invite}) to participate in this giveaway!`
    }


    // start giveaway
    client.giveawaysManager.start(giveawayChannel, {
      // The giveaway duration
      duration: ms(giveawayDuration),
      // The giveaway prize
      prize: giveawayPrize,
      // The giveaway winner count
      winnerCount: parseInt(giveawayWinnerCount),
      // BonusEntries If Provided
      bonusEntries: [
        {
          // Members who have the role which is assigned to "rolename" get the amount of bonus entries which are assigned to "BonusEntries"
          bonus: new Function('member', `return member.roles.cache.some((r) => r.name === \'${bonusRole ?.name}\') ? ${bonusEntries} : null`),
          cumulative: false
        }
      ],
      // Messages
      messages,
      extraData: {
        server: reqinvite == null ? "null" : reqinvite.guild.id,
        role: rolereq == null ? "null" : rolereq.id,
      }
    });
    const giveaway = new MessageEmbed()
    .setTitle("<:zen_gwlogo:965439275388784741> GIVEAWAY STARTED")
    .setDescription(`Giveaway started in ${giveawayChannel}!`)
    .setColor("WHITE")
    .setFooter(client.user.username, client.user.displayAvatarURL())
    .setTimestamp()
    interaction.editReply({ embeds: [giveaway], ephemeral: true })

    if (bonusRole) {
      let giveaway = new Discord.MessageEmbed()
        .setAuthor(`Bonus Entries Alert!`)
        .setDescription(
          `**${bonusRole}** Has **${bonusEntries}** Extra Entries in this giveaway!`
        )
        .setColor("WHITE")
        .setTimestamp();
      giveawayChannel.send({ embeds: [giveaway] });
    }

  }

};

/**********************************************************
 * @INFO
 * Bot Coded by Maxim.#3676 | https://discord.gg/WvMbuGj6VZ
 **********************************************************/